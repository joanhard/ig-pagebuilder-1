<?php
/**
 * Plugin Name: IG Free Shortcodes
 * Plugin URI: http://innogears.com
 * Description: Awesome content builder for Wordpress websites
 * Version: 1.0
 * Author: InnoGears Team <support@innogears.com>
 * Author URI: http://innogears.com
 * License: GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 */

add_action( 'ig_pb_third_party', 'ig_pb_free_sc_init' );
function ig_pb_free_sc_init(){

	class IG_Pb_Free_Shortcode extends Ig_Pb_Third_Party {

		public function __construct() {

			// setup information
			$this->set_provider(
				array(
					'name' => 'InnoGears',
					'file' => __FILE__,
					'shortcode_dir' => 'shortcodes',
					'js_shortcode_dir' => 'assets/js/shortcodes',
				)
			);

			//$this->custom_assets();

			// call parent construct
			parent::__construct();
		}

		// regiter & enqueue custom assets
		public function custom_assets() {
			// register custom assets
			$this->set_assets_register(
				array(
					'ig-frontend-free-css' => array(
						'src' => plugins_url( 'assets/css/main.css' , dirname( __FILE__ ) ),
						'ver' => '1.0.0',
					),
					'ig-frontend-free-js' => array(
						'src' => plugins_url( 'assets/js/main.js' , dirname( __FILE__ ) ),
						'ver' => '1.0.0',
					)
				)
			);
			// enqueue assets for Admin pages
			$this->set_assets_enqueue_admin( array( 'ig-frontend-free-css' ) );
			// enqueue assets for Modal setting iframe
			$this->set_assets_enqueue_modal( array( 'ig-frontend-free-js' ) );
			// enqueue assets for Frontend
			$this->set_assets_enqueue_frontend( array( 'ig-frontend-free-css', 'ig-frontend-free-js' ) );
		}
	}
	$this_ = new IG_Pb_Free_Shortcode();

}