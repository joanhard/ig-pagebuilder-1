<?php
/**
 * Plugin Name: IT Free Shortcodes
 * Plugin URI: http://innothemes.com
 * Description: Awesome content builder for Wordpress websites
 * Version: 1.0
 * Author: InnoThemes Team <support@innothemes.com>
 * Author URI: http://innothemes.com
 * License: GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
 */

add_action( 'ig_pb_third_party', 'ig_pb_free_sc_init' );
function ig_pb_free_sc_init(){

	class IG_Pb_Free_Shortcode extends Ig_Pb_Third_Party {

		public function __construct() {
			$this->define = array(
				'this_name' => 'InnoGears',
				'this_path' => plugin_dir_path( __FILE__ ),
				'this_uri' => plugin_dir_url( __FILE__ ),
			);

			// setup information
			$this->set_provider(
				array(
					'path' => $this->define['this_path'],
					'uri' => $this->define['this_uri'],
                    'main_file' => 'ig-shortcodes-free/main.php',
					'name' => $this->define['this_name'],
					'shortcode_dir' => 'shortcodes',
					'js_shortcode_dir' => 'assets/js/shortcodes',
				)
			);

			//$this->custom_assets();

			// call parent construct
			parent::__construct();
		}

		// regiter & enqueue custom assets
		public function custom_assets() {
			// register custom assets
			$this->set_assets_register(
				array(
					'ig-frontend-css' => array(
						'src' => IG_Pb_Helper_Functions::path( 'assets', $this->define['this_uri'] ) . '/css/main.css',
						'ver' => '1.0.0',
					),
					'ig-frontend-js' => array(
						'src' => IG_Pb_Helper_Functions::path( 'assets', $this->define['this_uri'] ) . '/js/main.js',
						'ver' => '1.0.0',
					)
				)
			);
			// enqueue assets for Admin pages
			$this->set_assets_enqueue_admin( array( 'ig-frontend-css' ) );
			// enqueue assets for Modal setting iframe
			$this->set_assets_enqueue_modal( array( 'ig-frontend-js' ) );
			// enqueue assets for Frontend
			$this->set_assets_enqueue_frontend( array( 'ig-frontend-css', 'ig-frontend-js' ) );
		}
	}
	$this_ = new IG_Pb_Free_Shortcode();

}